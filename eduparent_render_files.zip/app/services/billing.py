from __future__ import annotations
from datetime import date, datetime
from app.db.database import connect

def money(n:int) -> str:
    return f"{int(n):,}".replace(',', ' ') + " so‘m"

def audit(conn, user_id, action, entity_type, entity_id=None, details=''):
    conn.execute('INSERT INTO audit_logs(user_id,action,entity_type,entity_id,details) VALUES(?,?,?,?,?)',
                 (user_id, action, entity_type, entity_id, details))

def tariff_for(conn, study_type: str, on_date: str):
    return conn.execute('''SELECT * FROM tariffs WHERE study_type=? AND active=1
        AND valid_from<=? AND (valid_to IS NULL OR valid_to>=?)
        ORDER BY valid_from DESC, id DESC LIMIT 1''', (study_type, on_date, on_date)).fetchone()

def discount_for(conn, student_id:int, on_date:str):
    return conn.execute('''SELECT * FROM discounts WHERE student_id=? AND valid_from<=?
        AND (valid_to IS NULL OR valid_to>=?) ORDER BY valid_from DESC,id DESC LIMIT 1''',
        (student_id,on_date,on_date)).fetchone()

def create_invoice(student_id:int, billing_month:str, user_id:int):
    with connect() as conn:
        existing = conn.execute('SELECT * FROM invoices WHERE student_id=? AND billing_month=?',
                                (student_id,billing_month)).fetchone()
        if existing: return dict(existing)
        student = conn.execute('SELECT * FROM students WHERE id=?', (student_id,)).fetchone()
        if not student: raise ValueError('O‘quvchi topilmadi')
        tariff = tariff_for(conn, student['study_type'], billing_month + '-01')
        if not tariff: raise ValueError('Amaldagi tarif topilmadi')
        base = int(tariff['amount'])
        d = discount_for(conn, student_id, billing_month + '-01')
        disc = round(base * int(d['percent']) / 100) if d else 0
        due = base - disc
        credit = min(int(student['credit_balance']), due)
        due_after_credit = due - credit
        cur = conn.execute('''INSERT INTO invoices(student_id,billing_month,base_amount,discount_amount,amount_due,
                   amount_paid,credit_applied,created_by) VALUES(?,?,?,?,?,?,?,?)''',
                   (student_id,billing_month,base,disc,due_after_credit,0,credit,user_id))
        if credit:
            conn.execute('UPDATE students SET credit_balance=credit_balance-? WHERE id=?', (credit,student_id))
        audit(conn,user_id,'CREATE','invoice',cur.lastrowid,f'month={billing_month}; snapshot_tariff={base}')
        conn.commit()
        row = conn.execute('SELECT * FROM invoices WHERE id=?',(cur.lastrowid,)).fetchone()
        return dict(row)

def record_payment(student_id:int, invoice_id:int|None, amount:int, key:str, user_id:int, note=''):
    amount = int(amount)
    if amount <= 0: raise ValueError('Summa 0 dan katta bo‘lishi kerak')
    with connect() as conn:
        old = conn.execute('SELECT * FROM payments WHERE idempotency_key=?',(key,)).fetchone()
        if old: return dict(old), False
        applied = excess = 0
        if invoice_id:
            inv = conn.execute('SELECT * FROM invoices WHERE id=? AND student_id=?',(invoice_id,student_id)).fetchone()
            if not inv: raise ValueError('Hisob topilmadi')
            debt = max(0, int(inv['amount_due']) - int(inv['amount_paid']))
            applied = min(debt, amount)
            excess = amount - applied
            conn.execute('UPDATE invoices SET amount_paid=amount_paid+? WHERE id=?',(applied,invoice_id))
        else:
            excess = amount
        if excess:
            conn.execute('UPDATE students SET credit_balance=credit_balance+? WHERE id=?',(excess,student_id))
        cur=conn.execute('''INSERT INTO payments(student_id,invoice_id,amount,applied_amount,excess_amount,idempotency_key,note,created_by)
                            VALUES(?,?,?,?,?,?,?,?)''',(student_id,invoice_id,amount,applied,excess,key,note,user_id))
        audit(conn,user_id,'CREATE','payment',cur.lastrowid,f'amount={amount}; applied={applied}; excess={excess}')
        conn.commit()
        return dict(conn.execute('SELECT * FROM payments WHERE id=?',(cur.lastrowid,)).fetchone()), True

def refund_payment(payment_id:int, amount:int, reason:str, user_id:int):
    amount=int(amount)
    with connect() as conn:
        p=conn.execute('SELECT * FROM payments WHERE id=?',(payment_id,)).fetchone()
        if not p: raise ValueError('To‘lov topilmadi')
        available=int(p['amount'])-int(p['refunded_amount'])
        if amount<=0 or amount>available: raise ValueError('Qaytarish summasi noto‘g‘ri')
        remaining=amount
        excess_refund=min(remaining, int(p['excess_amount']))
        if excess_refund:
            bal=conn.execute('SELECT credit_balance FROM students WHERE id=?',(p['student_id'],)).fetchone()['credit_balance']
            if bal < excess_refund: raise ValueError('Ortiqcha to‘lov qoldig‘i allaqachon ishlatilgan')
            conn.execute('UPDATE students SET credit_balance=credit_balance-? WHERE id=?',(excess_refund,p['student_id']))
            remaining-=excess_refund
        if remaining and p['invoice_id']:
            conn.execute('UPDATE invoices SET amount_paid=MAX(0,amount_paid-?) WHERE id=?',(remaining,p['invoice_id']))
        cur=conn.execute('INSERT INTO refunds(payment_id,amount,reason,created_by) VALUES(?,?,?,?)',(payment_id,amount,reason,user_id))
        conn.execute('UPDATE payments SET refunded_amount=refunded_amount+? WHERE id=?',(amount,payment_id))
        audit(conn,user_id,'REFUND','payment',payment_id,f'amount={amount}; reason={reason}')
        conn.commit()
        return cur.lastrowid
