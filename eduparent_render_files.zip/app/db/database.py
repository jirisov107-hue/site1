from __future__ import annotations
import os, sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
DB_PATH = Path(os.getenv('DATABASE_PATH', BASE_DIR / 'school_billing.db'))
if not DB_PATH.is_absolute():
    DB_PATH = (BASE_DIR / DB_PATH).resolve()
MIGRATION = BASE_DIR / 'migrations' / '001_init.sql'

def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn

def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect() as conn:
        conn.executescript(MIGRATION.read_text(encoding='utf-8'))
        conn.commit()
