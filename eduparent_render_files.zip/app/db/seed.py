from app.db.database import init_db, connect
from app.services.security import hash_password

# Demo loginlar faqat kodda saqlanadi; login sahifasi va README'da ko'rsatilmaydi.
DEMO_USERS = [
    ('admin', 'Admin2026!', 'admin', 'Bosh administrator'),
    ('accountant', 'Account2026!', 'accountant', 'Maktab buxgalteri'),
    ('parent', 'Parent2026!', 'parent', 'Ota-ona demo'),
]

def main():
    init_db()
    with connect() as conn:
        for username, password, role, full_name in DEMO_USERS:
            conn.execute('''INSERT OR IGNORE INTO users(username,password_hash,role,full_name)
                            VALUES(?,?,?,?)''', (username, hash_password(password), role, full_name))
        # Faqat strukturaviy guruhlar. O'quvchi, hisob yoki to'lov avtomatik yaratilmaydi.
        conn.execute("INSERT OR IGNORE INTO groups(name, description) VALUES('9-A','Demo guruh')")
        conn.execute("INSERT OR IGNORE INTO groups(name, description) VALUES('10-B','Demo guruh')")
        conn.commit()
    print('Seed completed.')

if __name__ == '__main__':
    main()
