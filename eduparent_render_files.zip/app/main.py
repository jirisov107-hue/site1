from __future__ import annotations
import os, csv, io, secrets
from pathlib import Path
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from app.db.database import init_db, connect
from app.services.security import verify_password, hash_password
from app.services.billing import create_invoice, record_payment, refund_payment, audit, money

BASE=Path(__file__).resolve().parent
app=FastAPI(title='SchoolPay Guardian API')
app.add_middleware(SessionMiddleware, secret_key=os.getenv('SECRET_KEY','dev-change-me'))
app.mount('/static', StaticFiles(directory=BASE/'static'), name='static')
templates=Jinja2Templates(directory=BASE/'templates')
templates.env.globals['money']=money

@app.on_event('startup')
def startup(): init_db()

def current_user(request:Request):
    uid=request.session.get('user_id')
    if not uid: return None
    with connect() as conn:
        row=conn.execute('SELECT id,username,role,full_name FROM users WHERE id=? AND active=1',(uid,)).fetchone()
        return dict(row) if row else None

def need(request:Request, roles=None):
    u=current_user(request)
    if not u: raise HTTPException(401,'Login required')
    if roles and u['role'] not in roles: raise HTTPException(403,'Ruxsat yo‘q')
    return u

@app.get('/',response_class=HTMLResponse)
def root(request:Request):
    u=current_user(request)
    if not u: return RedirectResponse('/login',303)
    return RedirectResponse('/parent' if u['role']=='parent' else '/dashboard',303)

@app.get('/login',response_class=HTMLResponse)
def login_page(request:Request):
    return templates.TemplateResponse('login.html',{'request':request,'error':None})

@app.post('/login',response_class=HTMLResponse)
def login(request:Request, username:str=Form(...), password:str=Form(...)):
    with connect() as conn:
        u=conn.execute('SELECT * FROM users WHERE username=? AND active=1',(username.strip(),)).fetchone()
        if not u or not verify_password(password,u['password_hash']):
            return templates.TemplateResponse('login.html',{'request':request,'error':'Login yoki parol noto‘g‘ri'},status_code=401)
        request.session['user_id']=u['id']
        audit(conn,u['id'],'LOGIN','session',None,'web login')
        conn.commit()
        target='/parent' if u['role']=='parent' else '/dashboard'
    return RedirectResponse(target,303)

@app.get('/logout')
def logout(request:Request):
    request.session.clear(); return RedirectResponse('/login',303)

@app.get('/dashboard',response_class=HTMLResponse)
def dashboard(request:Request):
    u=need(request,['admin','accountant'])
    with connect() as conn:
        stats={
          'students':conn.execute('SELECT COUNT(*) c FROM students WHERE active=1').fetchone()['c'],
          'groups':conn.execute('SELECT COUNT(*) c FROM groups WHERE active=1').fetchone()['c'],
          'today':conn.execute("SELECT COALESCE(SUM(amount-refunded_amount),0) s FROM payments WHERE date(created_at)=date('now')").fetchone()['s'],
          'debt':conn.execute('SELECT COALESCE(SUM(MAX(amount_due-amount_paid,0)),0) s FROM invoices').fetchone()['s'],
        }
        students=[dict(r) for r in conn.execute('''SELECT s.*,g.name group_name FROM students s JOIN groups g ON g.id=s.group_id ORDER BY s.id DESC LIMIT 8''')]
        payments=[dict(r) for r in conn.execute('''SELECT p.*,s.first_name||' '||s.last_name student_name,u.username creator
             FROM payments p JOIN students s ON s.id=p.student_id JOIN users u ON u.id=p.created_by ORDER BY p.id DESC LIMIT 8''')]
        groups=[dict(r) for r in conn.execute('SELECT * FROM groups WHERE active=1 ORDER BY name')]
        tariffs=[dict(r) for r in conn.execute('SELECT * FROM tariffs ORDER BY valid_from DESC,id DESC LIMIT 10')]
    return templates.TemplateResponse('dashboard.html',{'request':request,'user':u,'stats':stats,'students':students,'payments':payments,'groups':groups,'tariffs':tariffs})

@app.get('/parent',response_class=HTMLResponse)
def parent_panel(request:Request, student_id:int|None=None):
    u=need(request,['parent'])
    with connect() as conn:
        children=[dict(r) for r in conn.execute('''SELECT s.*,g.name group_name FROM parent_students ps
            JOIN students s ON s.id=ps.student_id JOIN groups g ON g.id=s.group_id
            WHERE ps.parent_user_id=? AND s.active=1 ORDER BY s.last_name,s.first_name''',(u['id'],))]
        if not children:
            return templates.TemplateResponse('parent.html',{'request':request,'user':u,'children':[]})
        allowed={c['id'] for c in children}
        selected_id=student_id if student_id in allowed else children[0]['id']
        selected=next(c for c in children if c['id']==selected_id)
        invoices=[dict(r) for r in conn.execute('''SELECT i.*,MAX(i.amount_due-i.amount_paid,0) debt
            FROM invoices i WHERE i.student_id=? ORDER BY i.billing_month DESC,i.id DESC''',(selected_id,))]
        payments=[dict(r) for r in conn.execute('''SELECT p.* FROM payments p WHERE p.student_id=? ORDER BY p.id DESC''',(selected_id,))]
        discounts=[dict(r) for r in conn.execute('''SELECT * FROM discounts WHERE student_id=? ORDER BY id DESC''',(selected_id,))]
        refunds=[dict(r) for r in conn.execute('''SELECT r.* FROM refunds r JOIN payments p ON p.id=r.payment_id
            WHERE p.student_id=? ORDER BY r.id DESC''',(selected_id,))]
        total_due=sum(int(i['amount_due']) for i in invoices)
        total_paid=sum(int(i['amount_paid']) for i in invoices)
        debt=sum(max(0,int(i['amount_due'])-int(i['amount_paid'])) for i in invoices)
        over30=conn.execute("""SELECT COALESCE(SUM(MAX(amount_due-amount_paid,0)),0) s FROM invoices
            WHERE student_id=? AND amount_paid<amount_due AND date(created_at)<=date('now','-30 day')""",(selected_id,)).fetchone()['s']
        summary={'total_due':total_due,'total_paid':total_paid,'debt':debt,'over30':over30}
    return templates.TemplateResponse('parent.html',{'request':request,'user':u,'children':children,'selected':selected,
        'invoices':invoices,'payments':payments,'discounts':discounts,'refunds':refunds,'summary':summary})

@app.post('/parent/link-child')
def parent_link_child(request:Request, student_code:str=Form(...), parent_pin:str=Form(...)):
    u=need(request,['parent'])
    code=student_code.strip().upper()
    pin=parent_pin.strip()
    with connect() as conn:
        student=conn.execute('''SELECT s.id,s.first_name,s.last_name FROM students s
            WHERE s.student_code=? AND s.parent_pin=? AND s.active=1''',(code,pin)).fetchone()
        if not student:
            children=[dict(r) for r in conn.execute('''SELECT s.*,g.name group_name FROM parent_students ps
                JOIN students s ON s.id=ps.student_id JOIN groups g ON g.id=s.group_id
                WHERE ps.parent_user_id=? AND s.active=1 ORDER BY s.last_name,s.first_name''',(u['id'],))]
            return templates.TemplateResponse('parent.html',{'request':request,'user':u,'children':children,
                'link_error':'O‘quvchi kodi yoki tasdiqlash PIN noto‘g‘ri.'},status_code=400)
        conn.execute('INSERT OR IGNORE INTO parent_students(parent_user_id,student_id) VALUES(?,?)',(u['id'],student['id']))
        audit(conn,u['id'],'LINK_CHILD','parent_student',student['id'],f'{student["first_name"]} {student["last_name"]}; code={code}')
        conn.commit()
    return RedirectResponse(f'/parent?student_id={student["id"]}',303)

@app.post('/parent/unlink-child')
def parent_unlink_child(request:Request, student_id:int=Form(...)):
    u=need(request,['parent'])
    with connect() as conn:
        linked=conn.execute('SELECT 1 FROM parent_students WHERE parent_user_id=? AND student_id=?',(u['id'],student_id)).fetchone()
        if not linked: raise HTTPException(404,'Farzand biriktirilmagan')
        conn.execute('DELETE FROM parent_students WHERE parent_user_id=? AND student_id=?',(u['id'],student_id))
        audit(conn,u['id'],'UNLINK_CHILD','parent_student',student_id,'Parent removed child link')
        conn.commit()
    return RedirectResponse('/parent',303)

@app.get('/students',response_class=HTMLResponse)
def students_page(request:Request):
    u=need(request,['admin','accountant'])
    with connect() as conn:
        rows=[dict(r) for r in conn.execute('''SELECT s.*,g.name group_name FROM students s JOIN groups g ON g.id=s.group_id ORDER BY s.id DESC''')]
        groups=[dict(r) for r in conn.execute('SELECT * FROM groups WHERE active=1 ORDER BY name')]
    return templates.TemplateResponse('students.html',{'request':request,'user':u,'students':rows,'groups':groups})

@app.post('/students')
def add_student(request:Request, first_name:str=Form(...), last_name:str=Form(...), group_id:int=Form(...), study_type:str=Form(...)):
    u=need(request,['admin'])
    with connect() as conn:
        # Ota-ona farzandni xavfsiz biriktirishi uchun maktab beradigan kod va PIN.
        while True:
            student_code='STU-' + secrets.token_hex(3).upper()
            exists=conn.execute('SELECT 1 FROM students WHERE student_code=?',(student_code,)).fetchone()
            if not exists: break
        parent_pin=f'{secrets.randbelow(1000000):06d}'
        cur=conn.execute('INSERT INTO students(first_name,last_name,group_id,study_type,student_code,parent_pin) VALUES(?,?,?,?,?,?)',
            (first_name.strip(),last_name.strip(),group_id,study_type,student_code,parent_pin))
        audit(conn,u['id'],'CREATE','student',cur.lastrowid,f'{first_name} {last_name}; code={student_code}')
        conn.commit()
    return RedirectResponse('/students',303)

@app.post('/groups')
def add_group(request:Request, name:str=Form(...), description:str=Form('')):
    u=need(request,['admin'])
    with connect() as conn:
        cur=conn.execute('INSERT INTO groups(name,description) VALUES(?,?)',(name.strip(),description.strip()))
        audit(conn,u['id'],'CREATE','group',cur.lastrowid,name); conn.commit()
    return RedirectResponse('/dashboard',303)

@app.post('/tariffs')
def add_tariff(request:Request,name:str=Form(...),study_type:str=Form(...),amount:int=Form(...),valid_from:str=Form(...),valid_to:str=Form('')):
    u=need(request,['admin'])
    with connect() as conn:
        cur=conn.execute('INSERT INTO tariffs(name,study_type,amount,valid_from,valid_to) VALUES(?,?,?,?,?)',(name,study_type,int(amount),valid_from,valid_to or None))
        audit(conn,u['id'],'CREATE','tariff',cur.lastrowid,f'amount={amount}; from={valid_from}'); conn.commit()
    return RedirectResponse('/dashboard',303)

@app.get('/billing',response_class=HTMLResponse)
def billing_page(request:Request):
    u=need(request,['admin','accountant'])
    with connect() as conn:
        students=[dict(r) for r in conn.execute('''SELECT s.id,s.first_name,s.last_name,g.name group_name,s.credit_balance FROM students s JOIN groups g ON g.id=s.group_id WHERE s.active=1 ORDER BY s.last_name''')]
        invoices=[dict(r) for r in conn.execute('''SELECT i.*,s.first_name||' '||s.last_name student_name,g.name group_name FROM invoices i JOIN students s ON s.id=i.student_id JOIN groups g ON g.id=s.group_id ORDER BY i.billing_month DESC,i.id DESC LIMIT 100''')]
    return templates.TemplateResponse('billing.html',{'request':request,'user':u,'students':students,'invoices':invoices})

@app.post('/billing/invoice')
def make_invoice(request:Request,student_id:int=Form(...),billing_month:str=Form(...)):
    u=need(request,['admin','accountant'])
    create_invoice(student_id,billing_month,u['id'])
    return RedirectResponse('/billing',303)

@app.post('/billing/discount')
def make_discount(request:Request,student_id:int=Form(...),percent:int=Form(...),valid_from:str=Form(...),valid_to:str=Form(''),reason:str=Form(...)):
    u=need(request,['admin','accountant'])
    with connect() as conn:
        cur=conn.execute('INSERT INTO discounts(student_id,percent,valid_from,valid_to,reason,created_by) VALUES(?,?,?,?,?,?)',(student_id,percent,valid_from,valid_to or None,reason,u['id']))
        audit(conn,u['id'],'CREATE','discount',cur.lastrowid,f'{percent}% {reason}'); conn.commit()
    return RedirectResponse('/billing',303)

@app.get('/payments',response_class=HTMLResponse)
def payments_page(request:Request):
    u=need(request,['admin','accountant'])
    with connect() as conn:
        students=[dict(r) for r in conn.execute("SELECT id,first_name||' '||last_name name FROM students WHERE active=1 ORDER BY last_name")]
        invoices=[dict(r) for r in conn.execute('''SELECT i.id,i.student_id,i.billing_month,i.amount_due,i.amount_paid,s.first_name||' '||s.last_name student_name FROM invoices i JOIN students s ON s.id=i.student_id WHERE i.amount_paid<i.amount_due ORDER BY i.billing_month DESC''')]
        payments=[dict(r) for r in conn.execute('''SELECT p.*,s.first_name||' '||s.last_name student_name,u.username creator FROM payments p JOIN students s ON s.id=p.student_id JOIN users u ON u.id=p.created_by ORDER BY p.id DESC LIMIT 100''')]
    return templates.TemplateResponse('payments.html',{'request':request,'user':u,'students':students,'invoices':invoices,'payments':payments,'new_key':secrets.token_hex(16)})

@app.post('/payments')
def add_payment(request:Request,student_id:int=Form(...),invoice_id:str=Form(''),amount:int=Form(...),idempotency_key:str=Form(...),note:str=Form('')):
    u=need(request,['admin','accountant'])
    record_payment(student_id,int(invoice_id) if invoice_id else None,amount,idempotency_key,u['id'],note)
    return RedirectResponse('/payments',303)

@app.post('/payments/{payment_id}/refund')
def refund(request:Request,payment_id:int,amount:int=Form(...),reason:str=Form(...)):
    u=need(request,['admin','accountant'])
    refund_payment(payment_id,amount,reason,u['id'])
    return RedirectResponse('/payments',303)

@app.get('/reports',response_class=HTMLResponse)
def reports(request:Request,group_id:str='',date_from:str='',date_to:str='',over30:int=0):
    u=need(request,['admin','accountant'])
    cond=['1=1']; params=[]
    if group_id: cond.append('g.id=?'); params.append(int(group_id))
    if date_from: cond.append('date(i.created_at)>=date(?)'); params.append(date_from)
    if date_to: cond.append('date(i.created_at)<=date(?)'); params.append(date_to)
    if over30: cond.append("date(i.created_at)<=date('now','-30 day') AND i.amount_paid<i.amount_due")
    sql=f'''SELECT i.*,s.first_name||' '||s.last_name student_name,g.name group_name,
      MAX(i.amount_due-i.amount_paid,0) debt FROM invoices i JOIN students s ON s.id=i.student_id JOIN groups g ON g.id=s.group_id
      WHERE {' AND '.join(cond)} ORDER BY debt DESC,i.created_at ASC'''
    with connect() as conn:
        rows=[dict(r) for r in conn.execute(sql,params)]
        groups=[dict(r) for r in conn.execute('SELECT * FROM groups WHERE active=1 ORDER BY name')]
    return templates.TemplateResponse('reports.html',{'request':request,'user':u,'rows':rows,'groups':groups,'filters':{'group_id':group_id,'date_from':date_from,'date_to':date_to,'over30':over30}})

@app.get('/reports.csv')
def reports_csv(request:Request,group_id:str='',date_from:str='',date_to:str='',over30:int=0):
    need(request,['admin','accountant'])
    cond=['1=1']; params=[]
    if group_id: cond.append('g.id=?'); params.append(int(group_id))
    if date_from: cond.append('date(i.created_at)>=date(?)'); params.append(date_from)
    if date_to: cond.append('date(i.created_at)<=date(?)'); params.append(date_to)
    if over30: cond.append("date(i.created_at)<=date('now','-30 day') AND i.amount_paid<i.amount_due")
    sql=f'''SELECT i.billing_month,s.first_name||' '||s.last_name student,g.name group_name,i.amount_due,i.amount_paid,
            MAX(i.amount_due-i.amount_paid,0) debt,i.created_at FROM invoices i JOIN students s ON s.id=i.student_id JOIN groups g ON g.id=s.group_id WHERE {' AND '.join(cond)} ORDER BY i.id DESC'''
    with connect() as conn: rows=conn.execute(sql,params).fetchall()
    out=io.StringIO(); w=csv.writer(out); w.writerow(['oy','oquvchi','guruh','hisob','tolangan','qarz','yaratilgan'])
    for r in rows: w.writerow(list(r))
    return StreamingResponse(iter([out.getvalue()]),media_type='text/csv',headers={'Content-Disposition':'attachment; filename=qarzdorlik.csv'})

@app.get('/audit',response_class=HTMLResponse)
def audit_page(request:Request):
    u=need(request,['admin'])
    with connect() as conn:
        rows=[dict(r) for r in conn.execute('''SELECT a.*,COALESCE(u.username,'system') username FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200''')]
    return templates.TemplateResponse('audit.html',{'request':request,'user':u,'rows':rows})

@app.get('/users',response_class=HTMLResponse)
def users_page(request:Request):
    u=need(request,['admin'])
    with connect() as conn:
        rows=[dict(r) for r in conn.execute('''SELECT u.id,u.username,u.role,u.full_name,u.active,u.created_at,
          GROUP_CONCAT(s.first_name||' '||s.last_name, ', ') children
          FROM users u LEFT JOIN parent_students ps ON ps.parent_user_id=u.id
          LEFT JOIN students s ON s.id=ps.student_id GROUP BY u.id ORDER BY u.id''')]
        students=[dict(r) for r in conn.execute('''SELECT s.id,s.first_name,s.last_name,g.name group_name FROM students s JOIN groups g ON g.id=s.group_id WHERE s.active=1 ORDER BY s.last_name''')]
    return templates.TemplateResponse('users.html',{'request':request,'user':u,'rows':rows,'students':students})

@app.post('/users')
def add_user(request:Request,username:str=Form(...),password:str=Form(...),role:str=Form(...),full_name:str=Form(...),student_id:str=Form('')):
    u=need(request,['admin'])
    if role not in ('admin','accountant','parent'): raise HTTPException(400,'Noto‘g‘ri rol')
    with connect() as conn:
        cur=conn.execute('INSERT INTO users(username,password_hash,role,full_name) VALUES(?,?,?,?)',(username,hash_password(password),role,full_name))
        if role=='parent' and student_id:
            conn.execute('INSERT OR IGNORE INTO parent_students(parent_user_id,student_id) VALUES(?,?)',(cur.lastrowid,int(student_id)))
        audit(conn,u['id'],'CREATE','user',cur.lastrowid,f'{username}:{role}'); conn.commit()
    return RedirectResponse('/users',303)

@app.get('/api/me')
def api_me(request:Request): return current_user(request) or JSONResponse({'detail':'unauthorized'},401)
